package com.java8;

public interface Interface {
	//void mahesh();

	//int mahesh1(int m);
	
	String mahesh2();
}
