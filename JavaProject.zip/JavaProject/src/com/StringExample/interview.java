package com.StringExample;

public class interview {
public static void main(String[] args) {
	int a=10;
	for (int i = 1; i <=10; i++) {
		a=3*i;
		System.out.println(a);
	}
}
}
