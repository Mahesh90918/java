package com.collections;

import java.util.LinkedList;

public class linked {
	public static void main(String[] args) {
     LinkedList li=new LinkedList();
     li.add(0, "jsdzh");
     li.add(1, "jsdzh");
     li.add(1, "jsdzh");
     li.add(3, "jsdzh");
     li.add(1, "jsdzh");
     li.add(5, "jsdzh");
     System.out.println(li);
	}
}
