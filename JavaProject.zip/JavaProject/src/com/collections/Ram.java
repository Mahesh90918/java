package com.collections;

public class Ram {
 
	 public static void main(String[] args)
	 { 
	String s = "ONE"+1+2+"TWO"+"THREE"+3+4+"FOUR"+"FIVE"+5; 
	System.out.println(s); 
	} 
}


