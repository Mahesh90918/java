package com.collections;

import java.util.TreeSet;

public class Treeset {
	public static void main(String[] args) {
			TreeSet t=new TreeSet();
			//t.add(null);
			t.add("A");
			t.add("A");
			t.add("a");
			t.add("B");
			t.add("Z");
			t.add("L");
			//System.out.println(t);
		
			System.out.println(t);
	}

}
