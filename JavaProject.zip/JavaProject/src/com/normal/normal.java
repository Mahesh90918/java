package com.normal;

public class normal {
	public static void main(String[] args) {
//	System.out.println(10<<2);
//	System.out.println(10*Math.pow(2, 2));
//	System.out.println(10<<3);
//	System.out.println(10*Math.pow(2, 3));
//	System.out.println(10>>2);
//	System.out.println(10<<4);
//	System.out.println(10>>4);
//	System.out.println(10/16);
//	System.out.println(10/Math.pow(2, 4));
//	System.out.println(~10);
//	System.out.println(~(-10));
		System.out.println(5 & 1);
		int x = 7;
		System.out.println(x > 10 && 1 < x);// 1<x<10
		/*
		 * The key difference between && and & operators is that && supports
		 * short-circuit evaluations while & operator does not.
		 * Another difference is that && will evaluate the expression exp1, and
		 * immediately return a false value if exp1 is false.
		 */
	}
}
