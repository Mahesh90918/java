package com.normal;

public class Excep {
	public static void main(String[] args) throws ArithmeticException,NullPointerException {
		String str=null;
		
		System.out.println(str.length());
		System.out.println(10 / 0);
		
	}
}
