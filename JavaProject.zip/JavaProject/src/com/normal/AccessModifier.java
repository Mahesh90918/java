package com.normal;

strictfp class AccessModifier {
	public static void main(String[] args) {
		// What modifiers may be used with top-level class?
//			public, abstract and final,strictfp can be used for top-level class.
	}
}
