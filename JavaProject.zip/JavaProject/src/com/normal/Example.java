package com.normal;

public class Example {
	static public void main(String[] args) {
		System.out.println("\u0000");
		System.out.println("\u0063");
		System.out.println("\u0097");
		System.out.println(10+20+"msmds"+(10-20));
		System.out.println((char) 65);
	}
}
