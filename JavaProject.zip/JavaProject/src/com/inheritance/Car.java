package com.inheritance;

public class Car {

	public void getCar() {
		System.out.println("car");
	}

	public static void main(String[] args) {
System.out.println("car main method");
	}
}
