package com.inheritance;

public class Swift extends Car {

	public void getCar() {
		System.out.println("Swift");
	}

	public static void main(String[] args) {
		System.out.println("Swift main method");
	}
}
