package com.inheritance;

public class test {
	public static void main(String[] args) {
		Car car = new Swift();
      car.main(new String[] {"Hello"});
	}
}
