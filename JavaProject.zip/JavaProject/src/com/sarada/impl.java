package com.sarada;

public class impl implements inter{

	@Override
	public void sriman22() {
		// TODO Auto-generated method stub
		
	}
	public void mahesh22() {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
