package com.sarada;

public interface inter {
	void sriman22();
}
