package com.loops;

public class forloop2 {
	public static void main(String args[]) {
		int i = 0;
		for (System.out.println("hello"); i < 3; System.out.println("hi")) {
			i++;
		}
		
		int a=10,b=20;
		for(a=15;a<b;a++){
		System.out.println("hello");
		}
	}
}
