package com.inher;

public class a {
	public void mahesh() {
		System.out.println("jdgfjgadsfjg");
	}

//	public static void main(String[] args) {
//		System.out.println("a");
//	}
}
