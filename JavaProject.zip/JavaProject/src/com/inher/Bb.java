package com.inher;

public class Bb extends Aa {
@Override
int mahesh1(int s) {
	// TODO Auto-generated method stub
	return super.mahesh1(s);
}
private void mahesh() {
	// TODO Auto-generated method stub

}
}
