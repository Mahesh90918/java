package com.inher;

import java.util.Arrays;

public class b extends a {
//	public static void main(String[] args) {
//
//		int a = 10, b = 20;
//		a = b;
//		b = a;
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(a);
//	}

	public static void main(int[] x) {
		for (int i : x) {
			System.out.println(i);
		
	}
}
	public static void main(String[] args) {
//		int [] a= {1,3,4,5};
//		int [] b= {1,2,3,4,5};
//		main(a);
//		main(b);
		int [] b= new int[] {1,2,3,4,5};
		main(new int[] {1,47,85});
		main(b);
	}
}
