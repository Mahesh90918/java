package com.inher;

public class Cc extends Aa {

}
