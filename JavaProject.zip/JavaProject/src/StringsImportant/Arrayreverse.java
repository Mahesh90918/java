package StringsImportant;

public class Arrayreverse {
	public static void main(String[] args) {

		int p[] = { 1, 2, 2, 3, 4, 5, 55 };
		for (int i = p.length - 1; i >= 0; i--) {
			System.out.print(p[i] + ",");
		}
		
	}

}
